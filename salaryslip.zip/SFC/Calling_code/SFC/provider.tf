terraform {
  required_version = ">= 1.11.0, < 2.0.0"

  backend "azurerm" {
    storage_account_name = "aqainfterbackend01"
    container_name       = "nexus-tfstate"
  }
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "4.79.0"
    }
    safedns = {
      source  = "ans-group/safedns"
      version = "1.1.3"
    }
  }
}

provider "azurerm" {
  subscription_id             = var.subscription_id
  client_id                   = var.client_id
  client_certificate_path     = var.client_certificate_path
  client_certificate_password = var.client_certificate_password
  tenant_id                   = var.tenant_id
  environment                 = "public"
  features {}
}

provider "safedns" {
  api_key = var.ukfast_API_Key
}
