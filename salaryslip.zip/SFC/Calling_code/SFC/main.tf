module "load_balancer" {
  source = "../../modules/Load_Balancer"

  load_balancer_config = merge(local.load_balancer_config, {
    rg_name  = var.rg_name
    location = var.location
  })
}

module "service_fabric_cluster" {
  source = "../../modules/service_fabric_cluster"
  service_fabric_cluster_config = merge(local.service_fabric_cluster_config, {
    rg_name  = var.rg_name
    location = var.location
  })
}

module "virtual_machine_scale_set" {
  source = "../../modules/virtual_machine_scale_set"
  vmss_config = merge(local.vmss_config, {
    rg_name  = var.rg_name
    location = var.location
  })
}

module "management_lock" {
  source = "../../modules/management_lock"
  management_lock = merge(local.management_lock, {
    rg_name  = var.rg_name
    location = var.location
  })
}

module "azure_monitor_metric_alert" {
  source = "../../modules/azure_monitor_metric_alert"
  azure_monitor_metric_alert = merge(local.azure_monitor_metric_alert, {
    rg_name  = var.rg_name
    location = var.location
  })
}

module "safedns_record" {
  source = "../../modules/safedns_record"
  safedns_record = merge(local.safedns_record, {
    rg_name  = var.rg_name
    location = var.location
  })
}