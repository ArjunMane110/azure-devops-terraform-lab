variable "subscription_id" {
  description = "The Azure subscription ID"
  type        = string
}

variable "client_id" {
  description = "The service principal client ID"
  type        = string
}

variable "client_certificate_path" {
  description = "Path to the service principal certificate"
  type        = string
}

variable "client_certificate_password" {
  description = "Password for the service principal certificate"
  type        = string
  sensitive   = true
}

variable "tenant_id" {
  description = "The Azure AD tenant ID"
  type        = string
}

variable "rg_name" {
  description = "The name of the resource group"
  type        = string
}

variable "location" {
  description = "The Azure region for the resources"
  type        = string
}

variable "environment_name" {
  description = "The environment code used to select Service Fabric defaults"
  type        = string
}

variable "environment_instance" {
  description = "The environment instance number used by legacy naming conventions, for example 00 or 61"
  type        = string
}

variable "environment_region_code" {
  description = "Short Azure region code used by legacy naming and DNS conventions, for example EUW or EUN"
  type        = string
}

variable "cloudapp_region_by_code" {
  description = "Mapping from environment region code to Azure public cloudapp region segment used in SafeDNS CNAME targets"
  type        = map(string)
  default = {
    EUN = "northeurope"
    EUW = "westeurope"
  }
}

variable "ukfast_API_Key" {
  description = "The API Key to authenticate to UKFast SafeDNS"
  type        = string
  sensitive   = true
  default     = ""
}

variable "node_type_name" {
  description = "Optional override for Service Fabric node type name; defaults to computed VMSS name when empty"
  type        = string
  default     = ""
}

variable "instance_count" {
  description = "The number of instances for the node type (3=Bronze, 5+=Silver)"
  type        = number
  default     = 3

  validation {
    condition     = var.instance_count >= 1 && var.instance_count <= 100
    error_message = "instance_count must be between 1 and 100."
  }
}

variable "cert_thumbprint" {
  description = "The thumbprint of the certificate for Service Fabric cluster"
  type        = string
  default     = ""

  validation {
    condition     = var.cert_thumbprint == "" || (length(var.cert_thumbprint) == 40 && can(regex("^[A-F0-9]{40}$", var.cert_thumbprint)))
    error_message = "cert_thumbprint must be empty or a 40-character uppercase hexadecimal string."
  }
}

variable "cert_thumbprints" {
  description = "Service Fabric certificate thumbprints by environment"
  type        = map(string)
  default     = {}
}

variable "management_domain" {
  description = "The domain for Service Fabric management endpoint (e.g., aqa.org.uk)"
  type        = string
  default     = "aqa.org.uk"
}

variable "enable_aad" {
  description = "Whether to enable Azure Active Directory authentication"
  type        = bool
  default     = true
}

variable "aad_config" {
  description = "Azure Active Directory configuration"
  type = object({
    tenant_id              = string
    cluster_application_id = string
    client_application_id  = string
  })
  default = {
    tenant_id              = ""
    cluster_application_id = ""
    client_application_id  = ""
  }
}

variable "aad_overrides" {
  description = "Consolidated AAD overrides for environment-specific values."
  type = object({
    cluster_client_application_id = optional(string)
    cluster_application_id        = optional(string)
    vmss_client_application_id    = optional(string)
  })
  default = {}
}

variable "add_on_features" {
  description = "Add-on features to enable on the Service Fabric cluster"
  type        = list(string)
  default     = ["RepairManager"]
}

variable "sfc_overrides" {
  description = "Consolidated Service Fabric runtime overrides shared across environments."
  type = object({
    instance_count                     = optional(number)
    add_on_features                    = optional(list(string))
    vmss_network_interface_name        = optional(string)
    enable_azure_monitor_windows_agent = optional(bool)
  })
  default = {}

  validation {
    condition     = try(var.sfc_overrides.instance_count, null) == null || (var.sfc_overrides.instance_count >= 1 && var.sfc_overrides.instance_count <= 100)
    error_message = "sfc_overrides.instance_count must be between 1 and 100 when provided."
  }
}

variable "key_vault_secrets" {
  description = "Map of secrets to store in Key Vault"
  type        = map(string)
  sensitive   = true
  default     = {}
}

variable "storage_account_name" {
  description = "Storage account name for diagnostics (if not provided, will be derived from rg_name)"
  type        = string
  default     = ""
}

variable "protected_account_key_name" {
  description = "Name of the storage account key used for diagnostics configuration"
  type        = string
  default     = "StorageAccountKey1"
}

variable "protected_account_secondary_key_name" {
  description = "Name of the secondary storage account key secret used for diagnostics configuration"
  type        = string
  default     = "StorageAccountKey2"
}

variable "log_analytics_workspace_key_secret_name" {
  description = "Name of the Log Analytics workspace shared key secret"
  type        = string
  default     = "WorkspaceKey"
}

variable "certificate_store_name" {
  description = "Optional override for X509 certificate store name for Service Fabric cluster and VMSS node extension"
  type        = string
  default     = null
}

variable "virtual_network_name" {
  description = "Virtual network name hosting the VMSS subnet"
  type        = string
  default     = ""
}

variable "app_subnet_name" {
  description = "Subnet name used by the VMSS"
  type        = string
  default     = "app-subnet"
}

variable "vmss_name" {
  description = "Override for the virtual machine scale set name"
  type        = string
  default     = ""
}

variable "vmss_sku_name" {
  description = "VM SKU for the scale set"
  type        = string
  default     = "Standard_D3_v2"
}

variable "vmss_overprovision" {
  description = "Whether VMSS overprovision should be enabled"
  type        = bool
  default     = false
}

variable "vmss_admin_username" {
  description = "Local administrator username"
  type        = string

  validation {
    condition     = var.vmss_admin_username == "" || can(regex("^[a-zA-Z0-9_-]{3,32}$", var.vmss_admin_username))
    error_message = "vmss_admin_username must be empty or 3-32 characters (alphanumeric, underscore, hyphen only)."
  }
}

variable "vmss_admin_password" {
  description = "Local administrator password"
  type        = string
  sensitive   = true
}

variable "vmss_os_disk_type" {
  description = "Managed disk type for the OS disk"
  type        = string
  default     = "Standard_LRS"
}

variable "vmss_data_disk_size_gb" {
  description = "Data disk size in GB"
  type        = number
  default     = 10
}

variable "vmss_data_path" {
  description = "Optional override for Service Fabric data path configured on each VM instance"
  type        = string
  default     = null
}

variable "vmss_certificate_secret_name" {
  description = "Key Vault secret name containing the VMSS node certificate"
  type        = string
  default     = ""
}

variable "vmss_certificate_secret_url" {
  description = "Explicit Key Vault secret URL for the VMSS node certificate"
  type        = string
  default     = ""
}

variable "service_fabric_cluster_endpoint" {
  description = "Service Fabric cluster management endpoint passed to the node extension"
  type        = string
  default     = ""
}

variable "load_balancer_feature_overrides" {
  description = "Consolidated load balancer feature toggles for environment-specific behavior."
  type = object({
    enable_http_sys_rule    = optional(bool)
    enable_app_port_probe_1 = optional(bool)
    manage_safedns_record   = optional(bool)
  })
  default = {}
}

variable "application_insights_name" {
  description = "Application Insights resource name for VM diagnostics"
  type        = string
  default     = ""
}

variable "log_analytics_workspace_name" {
  description = "Log Analytics workspace name for VM monitoring"
  type        = string
  default     = ""
}

variable "load_balancer_backend_address_pool_id" {
  description = "Backend address pool ID of the load balancer this VMSS should join"
  type        = string
  default     = ""
}

variable "enable_management_locks" {
  description = "Enable CanNotDelete management locks for production-like service fabric resources"
  type        = bool
  default     = true
}

variable "enable_imports" {
  description = "When true, import blocks are active. Control via variable group per environment. Set to false after imports complete."
  type        = bool
  default     = false
}

variable "import_environment_key" {
  description = "Environment key allowed to activate import blocks, for example ENV-00. Leave empty to keep import blocks disabled even when enable_imports is true."
  type        = string
  default     = ""
}

variable "monitor_action_group_name" {
  description = "Name of the Monitor Action Group for alerts (defaults to 'default')"
  type        = string
  default     = ""
}

variable "diagnostic_storage_primary_access_key_secret_uri" {
  description = "Key Vault secret URI for diagnostics storage primary access key"
  type        = string
  default     = ""
}

variable "diagnostic_storage_secondary_access_key_secret_uri" {
  description = "Key Vault secret URI for diagnostics storage secondary access key"
  type        = string
  default     = ""
}

variable "log_analytics_primary_shared_key_secret_uri" {
  description = "Key Vault secret URI for Log Analytics primary shared key"
  type        = string
  default     = ""
}