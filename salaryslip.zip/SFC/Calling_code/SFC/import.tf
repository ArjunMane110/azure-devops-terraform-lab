import {
  for_each = local.import_marker
  to       = module.service_fabric_cluster.azurerm_service_fabric_cluster.sf_cluster
  id       = local.service_fabric_cluster_import_id
}

import {
  for_each = local.import_marker
  to       = module.virtual_machine_scale_set.azurerm_windows_virtual_machine_scale_set.service_fabric[0]
  id       = local.vmss_import_id
}

import {
  for_each = local.import_marker
  to       = module.load_balancer.azurerm_lb.service_fabric
  id       = local.load_balancer_import_id
}

import {
  for_each = local.import_marker
  to       = module.load_balancer.azurerm_lb_backend_address_pool.service_fabric
  id       = "${local.load_balancer_import_id}/backendAddressPools/${local.lb_import_names.backend_pool}"
}

import {
  for_each = local.import_marker
  to       = module.load_balancer.azurerm_lb_nat_pool.this["ssh"]
  id       = "${local.load_balancer_import_id}/inboundNatPools/${local.lb_import_names.nat_pool_ssh}"
}

import {
  for_each = local.import_marker
  to       = module.load_balancer.azurerm_lb_probe.this["fabric_gateway"]
  id       = "${local.load_balancer_import_id}/probes/${local.lb_import_names.probe_fabric_gateway}"
}

import {
  for_each = local.import_marker
  to       = module.load_balancer.azurerm_lb_probe.this["fabric_http_gateway"]
  id       = "${local.load_balancer_import_id}/probes/${local.lb_import_names.probe_fabric_http}"
}

import {
  for_each = local.import_marker
  to       = module.load_balancer.azurerm_lb_probe.this["https"]
  id       = "${local.load_balancer_import_id}/probes/${local.lb_import_names.probe_https}"
}

import {
  for_each = local.import_marker
  to       = module.load_balancer.azurerm_lb_probe.this["reverse_proxy"]
  id       = "${local.load_balancer_import_id}/probes/${local.lb_import_names.probe_reverse_proxy}"
}

import {
  for_each = local.import_marker
  to       = module.load_balancer.azurerm_lb_rule.this["fabric_gateway"]
  id       = "${local.load_balancer_import_id}/loadBalancingRules/${local.lb_import_names.rule_fabric_gateway}"
}

import {
  for_each = local.import_marker
  to       = module.load_balancer.azurerm_lb_rule.this["fabric_http"]
  id       = "${local.load_balancer_import_id}/loadBalancingRules/${local.lb_import_names.rule_fabric_http}"
}

import {
  for_each = local.import_marker
  to       = module.load_balancer.azurerm_lb_rule.this["https"]
  id       = "${local.load_balancer_import_id}/loadBalancingRules/${local.lb_import_names.rule_https}"
}

import {
  for_each = local.import_marker
  to       = module.load_balancer.azurerm_lb_rule.this["reverse_proxy"]
  id       = "${local.load_balancer_import_id}/loadBalancingRules/${local.lb_import_names.rule_reverse_proxy}"
}

import {
  for_each = local.import_http_sys_marker
  to       = module.load_balancer.azurerm_lb_probe.this["http_sys"]
  id       = "${local.load_balancer_import_id}/probes/${local.lb_import_names.probe_http_sys}"
}

import {
  for_each = local.import_http_sys_marker
  to       = module.load_balancer.azurerm_lb_rule.this["http_sys"]
  id       = "${local.load_balancer_import_id}/loadBalancingRules/${local.lb_import_names.rule_http_sys}"
}

import {
  for_each = local.import_app_port_1_marker
  to       = module.load_balancer.azurerm_lb_probe.this["app_port_1"]
  id       = "${local.load_balancer_import_id}/probes/${local.lb_import_names.probe_app_port_1}"
}

import {
  for_each = local.imports_enabled ? nonsensitive(var.key_vault_secrets) : {}
  to       = module.service_fabric_cluster.azurerm_key_vault_secret.sfc_secrets[lower("${var.rg_name}-${each.key}")]
  id       = "${trimsuffix(data.azurerm_key_vault.kv.vault_uri, "/")}/secrets/${lower("${var.rg_name}-${each.key}")}"
}