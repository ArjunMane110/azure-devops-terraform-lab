data "azurerm_resource_group" "rg" {
  name = var.rg_name
}

data "azurerm_storage_account" "diag" {
  name                = var.storage_account_name != "" ? var.storage_account_name : lower("${replace(var.rg_name, "-", "")}diag01")
  resource_group_name = var.rg_name
}

data "azurerm_key_vault" "kv" {
  name                = lower("${var.rg_name}-key")
  resource_group_name = var.rg_name
}

data "azurerm_resources" "virtual_machine_scale_sets" {
  type                = "Microsoft.Compute/virtualMachineScaleSets"
  resource_group_name = var.rg_name
}

data "azurerm_application_insights" "app_insights" {
  name                = local.application_insights_name
  resource_group_name = var.rg_name
}

data "azurerm_log_analytics_workspace" "log_analytics" {
  name                = local.log_analytics_workspace_name
  resource_group_name = var.rg_name
}

data "azurerm_key_vault_secret" "vmss_certificate" {
  count = var.vmss_certificate_secret_name != "" ? 1 : 0

  name         = var.vmss_certificate_secret_name
  key_vault_id = data.azurerm_key_vault.kv.id
}

data "azurerm_subnet" "app" {
  name                 = var.app_subnet_name
  virtual_network_name = local.virtual_network_name
  resource_group_name  = var.rg_name
}

data "azurerm_monitor_action_group" "default" {
  count               = local.apply_management_locks && var.monitor_action_group_name != "" ? 1 : 0
  resource_group_name = var.rg_name
  name                = var.monitor_action_group_name
}

data "safedns_zone" "aqa_org_uk_zone" {
  count = local.manage_safedns_record ? 1 : 0
  name  = var.management_domain
}